<?php
session_start();
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
    <!--Social Media Icons-->

    <link rel="stylesheet" href="css/all.css"/>

    <!-----Owl Carousel---->

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <!-- Custom Style -->
    <link rel="stylesheet" type="text/css" href="css/style1.css"/>
</head>
<body>
    <!-- ------------------------------Navigation -------------->

    <nav class="nav">
        <div class="nav-menu flex-row">
            <div class="nav-brand">
                <a href="#" class="text-gray">GameZone</a>
            </div>
            <div class="toggle-collapse">
                <div class="toggle-icons">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
            <div>
                <ul class="nav-items">
                    <li class="nav-link">
                        <a href="indexB.html">BLACK JACK</a>
                    </li>
                    <li class="nav-link">
                        <a href="indexS.html">SIMON GAME</a>
                    </li>
                    <li class="nav-link">
                        <a href="indexM.html">Flip Game</a>
                    </li>
                    <li class="nav-link">
                       <a  href="logout.php" class="btn btn-primary btn-large">Logout </a>
                    </li>
                </ul>
            </div>
            <div class="social text-gray">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </nav>


    <!-- ------------------------------Navigation -------------->

    <!-------------Main section of site------------------>

   <main>

       <!--------Site Title------------->

       <section class="site-title">
           <div class="site-background">
               <h3>Play beyond the way its meant to be Played!!</h3>
               <h1>GameZone: Now You're playing with power </h1>
               
           </div>
       </section>

       <!--------Site Title------------->

       <!--------------Blog Caraousel------------>

       <section>
           <div class="blog">
               <div class="container">
                   <div class="owl-carousel owl-theme blog-post">
                       <div class="blog-content">
                           <img src="BJ.jpg" alt="post-1">
                           <div class="blog-title">
                           <br><br><br>
                               <h3>Black Jack Game, play it now!!!</h3>
                               <button class="btn btn-blog">Card Games</button>
                               <span>Developed By: Sarthak Patel</span>
                               <br><br>
                           </div>
                       </div>
                       <div class="blog-content">
                           <img src="S.jpg" alt="post-1">
                           <div class="blog-title">
                           <br>
                               <h3>Simon Says!! Play Latest Game Now</h3>
                               <button class="btn btn-blog">React-Game</button>
                               <span>Developed by: Anushka Shukla</span>
                               <br><br>
                           </div>
                       </div>
                       <div class="blog-content">
                           <img src="memory.jpg" alt="post-1">
                           <div class="blog-title">
                               <h3>Check Your Memory With Animals</h3>
                               <button class="btn btn-blog">Flip Game</button>
                               <span>Developed By: Anuriya Shroti</span>
                               <br>
                           </div>
                       </div>
                       <div class="blog-content">
                           <img src="upgame.jpg" alt="post-1">
                           <div class="blog-title">
                           <br><br>
                               <h3>Many More Exciting games coming up!!!</h3>
                               <button class="btn btn-blog">Soon</button>
                               <span>Get Ready</span>
                               <br><br><br>
                           </div>
                       </div>
                   </div>
                   <div class="owl-navigation">
                       <span class="owl-nav-prev"><i class="fas fa-long-arrow-alt-left"></i></span>
                       <span class="owl-nav-next"><i class="fas fa-long-arrow-alt-right"></i></span>
                   </div>
               </div>
           </div>
       </section>

        <!--------------Blog Caraousel------------>
        <!----------------Site Content------------>

       <section class="container">
           <div class="site-content">
               <div class="posts">
                   <div class="post-content">
                       <div class="post-image">
                           <div>
                               <img src="zom.jpg" class="img" alt="blog-1">
                           </div>
                           <div class="post-info flex-row ">

                               <span>Zombie game Coming Soon!</span>
                           </div>
                       </div>
                       <div class="post-title">
                           <a href="#">We will try to bring it to you soon</a>
                           <p>A game filled with adventure and zombies is coming your way soon.
                             Just for your fun. Stay tuned...
                           </p>

                       </div>
                   </div>
                   <hr>
                   <div class="post-content">
                       <div class="post-image">
                           <div>
                               <img src="stick.jpg" class="img" alt="blog-1">
                           </div>
                           <div class="post-info flex-row ">

                               <span>Stick Monkey Game</span>
                           </div>
                       </div>
                       <div class="post-title">
                           <a href="#">A game for all age </a>
                           <p>This is fun as well as engaging game for all of you.
                             Its needs you at your best to win and get to the leadersboard.
                           </p>

                       </div>
                   </div>
                   <hr>

                   <div class="pagination flex-row">
                       <a href="#"><i class="fas fa-chevron-left"></i></a>
                       <a href="#" class="pages">1</a>
                       <a href="#" class="pages">2</a>
                       <a href="#" class="pages">3</a>
                       <a href="#"><i class="fas fa-chevron-right"></i></a>
                   </div>
               </div>
               <aside class="sidebar">
                   <div class="category">
                       <h2>Category</h2>
                       <ul class="category-list">
                           <li class="list-items">
                               <a href="#">Card Games</a>
                               <span>(01)</span>
                           </li>
                           <li class="list-items">
                               <a href="#">Memory Games</a>
                               <span>(01)</span>
                           </li>
                           <li class="list-items">
                               <a href="#">For all age games</a>
                               <span>(02)</span>
                           </li>
                           <li class="list-items">
                               <a href="#">Shooting</a>
                               <span>(soon)</span>
                           </li>
                           <li class="list-items">
                               <a href="#">Adventure</a>
                               <span>(soon)</span>
                           </li>

                       </ul>
                   </div>
                   <div class="popular-post">
                       <h2>Popular Games</h2>
                       <div class="post-content">
                           <div class="post-image">
                               <div>
                                   <img src="faug.jpg" class="img" alt="blog-1">
                               </div>
                               <div class="post-info flex-row ">

                                   <span>India</span>
                               </div>
                           </div>
                           <div class="post-title">
                               <a href="#">Fau-G has created its hype throughout the country!</a>

                           </div>
                       </div>
                       <div class="post-content">
                           <div class="post-image">
                               <div>
                                   <img src="valorant.jpg" class="img" alt="blog-1">
                               </div>
                               <div class="post-info flex-row ">

                                   <span>Valorant</span>
                               </div>
                           </div>
                           <div class="post-title">
                               <a href="#">Valorant has taken the complete industry under itself</a>

                           </div>

                       <div class="news-letter">
                           <h2>Subscribe for notifications</h2>
                           <div class="form-element">
                               <input type="text" class="input-element" placeholder="Email">
                               <button class="btn form-btn">Subscribe</button>
                           </div>
                       </div>
                   </div>
                   <div class="popular-tags">
                       <h2>Popular Games</h2>
                       <div class="tags">
                           <span class="tag">Among Us</span>
                           <span class="tag">Valorant</span>
                           <span class="tag">COD</span>

                       </div>
                   </div>
               </aside>
           </div>
       </section>

        <!----------------Site Content------------>


   </main>

   <!-------------Main section of site------------------>



      <!--------------------Footer-------------------->


       <footer class="footer">
           <div class="container">
               <div class="about-us">
                   <h2>About Us</h2>
                   <p>This website is developed by group consisting of 5 members as a prototype for the Challenging Task  activity for Internet and Web Programming class. </p>
                   <h4>Slot: B11+B12+B13</h4>
               </div>
               <div class="instagram">
                   <h2>Group Members</h2>
                   <div class="flex-column">
                       <h4>Anupriya Shroti</h4>
                       <h4>Anushka Shukla</h4>
                       <h4>Sachin Sikarwar</h4>
                       <h4>Sameer Bhadoriya</h4>
                       <h4>Sarthak Dushyant Patel</h4>
                   </div>
               </div>
               <div class="follow">
                   <h2>Follow Us</h2>
                   <i class="fab fa-facebook-f"></i>
                   <i class="fab fa-twitter"></i>
                   <i class="fab fa-instagram"></i>
                   <i class="fab fa-youtube"></i>

               </div>
           </div>
       </footer>

       <!--------------------Footer-------------------->


        <!--------Site Title------------->



        <!--------Site Title------------->
    </main>

    <!-------------Main section of site------------------>

    <!-----------Jquery Library file--------------->

    <script src="js/jquery.min.v3.5.1.js"></script>

    <!-- Custom JS-->
    <script src="js/main.js"></script>

    <!----------Owl Carousel JS----------->

   <script src="js/owl.carousel.min.js"></script>
</body>
</html>
<?php } ?>
